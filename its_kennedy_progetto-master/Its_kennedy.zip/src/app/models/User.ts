export class User{
    username:string;
    password:string;
    email:string;
    Nome_Admin:string;
    Cognome_Admin:string;
    SEDE_idSEDE:number;
    token:string;
    RUOLO:string;
}
export class Token{
    token:string;
}