"use strict";
exports.__esModule = true;
var User = /** @class */ (function () {
    function User() {
    }
    return User;
}());
exports.User = User;
